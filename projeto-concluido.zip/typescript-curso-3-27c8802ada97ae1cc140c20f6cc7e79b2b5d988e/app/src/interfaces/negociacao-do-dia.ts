export interface NegociacoesDoDia {
    montante: number;
    vezes: number;
}